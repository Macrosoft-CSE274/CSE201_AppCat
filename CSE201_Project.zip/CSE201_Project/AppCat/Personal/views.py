from django.shortcuts import render

def index(request):
    return render(request, 'Personal/home.html')
