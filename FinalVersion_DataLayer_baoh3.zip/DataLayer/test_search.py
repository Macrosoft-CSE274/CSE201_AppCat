import MySQLdb	
import sys	
# Connect
keyword = sys.argv[1]
db = MySQLdb.connect(host="localhost",
                     user="root",
                     passwd="6666",
                     db="dbAppStore")

cursor = db.cursor()
# Execute SQL select statement
finalList = []
# Execute SQL select statement
cursor.execute("use dbAppStore;")
cursor.execute("call spSearchAppByKeywords('" + keyword + "');")
# Get the number of rows in the resultset
numrows = cursor.rowcount
# Get and display one row at a time
for x in range(0, numrows):
	row = cursor.fetchone()
	for z in range(0, len(row)):
		app = {"name" : row[0],
            "developer" : row[3],
            "platform" : row[2],
            "versions" : "1.0",
            "rating" : row[6],}
	finalList.append(app)
for temp in finalList:
	print(temp)
# Close the connection
db.close()

