import MySQLdb		
# Connect
db = MySQLdb.connect(host="localhost",
                     user="root",
                     passwd="6666",
                     db="dbAppStore")

cursor = db.cursor()
# Execute SQL select statement
cursor.execute("use dbAppStore;")
cursor.execute("select * from tblUser")
# Get the number of rows in the resultset
print("Table tblUser Before Register Test")
numrows = cursor.rowcount
# Get and display one row at a time
result = cursor.fetchall()
print(result)
tempusername = "kunting2333"
tempfirst_name = "kunting"
templast_name="qi"
tempemail = "qi@2333.com"
temppassword1 = "2333xxxx"
temppassword2 = "2333xxxx"
cursor.execute("call spAddUser('" + tempusername + "','" +
                       tempfirst_name + "','" +
                       templast_name + "','" +
                       tempemail + "','" +
                       temppassword1 + "','" +
                       temppassword2 + "');")
db.commit()

cursor.execute("use dbAppStore;")
cursor.execute("select * from tblUser")
# Get the number of rows in the resultset
print("Table tblUser After Register Test")
numrows = cursor.rowcount
# Get and display one row at a time
result = cursor.fetchall()
print(result)
# Close the connection
db.close()

